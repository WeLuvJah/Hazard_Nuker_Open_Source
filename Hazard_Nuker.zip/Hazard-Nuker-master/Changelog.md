<p align= center</p><a href="https://rdimo.github.io/CheatAway/" target="_blank"><img src="https://cdn.discordapp.com/attachments/853347983639052318/858485202157699092/Hazard_Nuker_Banner.png" alt="HazardNuker"></a>

### 2021-9-26, v1.3.0
* ` Eyy source code release as promised`
* ` Fixed some stuff too but don't remember what I fixed`

### 2021-9-22, v1.2.9
* ` Made it so the title changes depending on what your doing now`
* ` Fixed a bug where the title didn't change`
* ` Fixed bug where the qr code grabber would crash`
* ` Fixed token grabber bug, yet again`

### 2021-9-19, v1.2.8
* ` New option! Mass DM, basically just dm's every friend that they have`
* ` Made it show the name instead of the id when removing friends, dms, guild etc except for when using dm spam since that was a pain to fix`
* ` All options runs 100x faster since I abuse threads now`
* ` Hazard runs alot smoother now since I cleaned up the code`
* ` Fixed a bug with the token grabber that it wouldn't install pyinstaller for you`
* ` Fixed a bug were the token grabber wouldn't grab passwords sometimes`

### 2021-9-13, v1.2.7
* ` Fixed a bug with token grabber since I forgot to remove on thing`
* ` Made it more clear when Hazard Nuker fails to update`
* ` Made it more clear on what to do with QR code grabber`

### 2021-9-13, v1.2.6
* ` Fixed a error that you couldn't create token grabber`
* ` Fixed Error Webhook a little`
* ` Made QR code grabber a little bit more clear`

### 2021-9-13, v1.2.5
* ` New option! QR Code grabber! Create a qr code and send it to users to steal their token!`
* ` Made Hazard Nuker send an error to your webhook incase you get one (easier for me to debug and you can send me the errors)`
* ` Disabled logs when logging into an account`
* ` Option 9 is not disable account instead of disable token since disable token got patched (more info https://github.com/Rdimo/Hazard-Nuker#9-disable-account)`
* ` You can now choose if you want to steal password or not`
* ` Just generally improved autoupdate`
* ` Fixed bug where the grabber would crash cuz it failed to get their language`
* ` Fixed bug with status changer and seizure that you would get an error sometimes`

### 2021-9-2, v1.2.4
* ` Fixed bug where you wouldn't get the password upon people running the token grabber`

### 2021-9-2, v1.2.3
* ` Fixed addiotional bugs`
* ` Made it check for another module and decreased the logs when creating the token grabber`

### 2021-9-2, v1.2.2
* ` Just fixed a bug were you couldn't create the token/password grabber`

### 2021-9-1, v1.2.1
* ` The token grabber now grabs password and creditcard info! The password will be sent over everytime the user updates the password/email or adds a cc (looks like this now https://imgur.com/bgDXl1F)`
* ` New option! Status changer so you can change their status to whatever you want`
* ` Added so you now see all the badges an account has when using option [7]`
* ` Made option [8] faster and just better working`
* ` Fixed so it now checks properly if you have pyinstaller installed and such`
* ` Fixed the valid webhook checker since it kinda crashed when an invalid webhook url was given`
* ` Fixed webhook spammer a bit, before the input in seconds would always add like +2-3sec`
* ` Fixed so you get the correct avatar url now for the account when using option [7]`
* ` Hazard nuker now downloads a chromedriver for you automatically`

### 2021-07-10, v1.2.0
* ` New option to delete all the private dm channels`
* ` Fixed so seizure mode is active while nuking the account so its even more annoying`
* ` Made it print slow now after almost every option`

### 2021-07-10, v1.1.9
* ` Improved mass report by quite alot:`
* ` made the title of the cmd change and show how many reports have been sent and the errors`
* ` Better error messages`
* ` Additionally added so you can choose how many reports you wanna send`
* ` Added alot more like reloading if you put wrong report option etc`
* ` changed the main gui a little bit and made it just more cleaner`
* ` Removed the loading at the start since it was kinda useless`
* ` Made checking for updates a loading bar instead of a slow print`

### 2021-07-09, v1.1.8
* ` Added option to delete webhook and made it as a second choice for choice [11]`
* ` improved token info by aloooot so now you get nitro info, billing info, avatar url and more small things`

### 2021-07-07, v1.1.7
* ` Fixed seizure mode to work while nuking the account`
* ` Fixed the Log into account actually work now (need correct driver for it)`

### 2021-07-07, v1.1.6
* ` Made auto update work a bit cleaner`
* ` You can now choose what message will be sent to every friend`
* ` You can now choose what the name of the servers will be `

### 2021-06-27, v1.1.5
* ` Added webhook spammer`
* ` Fixed the auto update, put the wrong link in before but now it works`
* ` Made it check for a valid webhook when creating the token grabber`
* ` Made the token grabbers console not popup anymore`
* ` You can now see the person set Language when using option [6]`

### 2021-06-26, v1.1.4
* ` Added Auto update functionality`
* ` Added mass report option to mass report a user`
* ` Added Token grabber creator, (https://imgur.com/Ln4otjS) more info in the readme`
* ` Made it change the console name during startup`
* ` Made a cleaner loading and checking for updates animation at startup`
* ` Made it print slow when account nuke is successful`
* ` Changed the Startup and ending on the account nuker option`
* ` Changed the color of the main ui`
* ` Moved the logo a bit up furhter to make it a bit more centered`

| 🌟Star This Repository If You Liked Hazard Nuker!|
|-------------------------------------------------|

|⚠️・ Hazard Nuker was made for educational purposes.・⚠️|
|-------------------------------------------------|

By using HazardNuker, you agree that you hold responsibility and accountability of any consequences caused by your actions

Created by Rdimo#6969 | https://rdimo.github.io/CheatAway
